\---

name: rust-rules-for-csharp

description: Apply Rust-inspired safety and explicitness rules plus high-value ideas from F#, Go, Kotlin, Swift, Erlang, and Goose when writing or refactoring C# code. Use when the user asks to make C# more Rust-like, apply functional or safe-systems principles, improve error handling, immutability, domain modeling, concurrency, safe async/await, data layout, allocation discipline, or mentions Result/Option, ownership thinking, discriminated unions, actor-style design, fearless concurrency, or flat/cache-friendly design in a C# context.

\---



\# Apply Cross-Language Safety \& Clarity Rules to C#



When editing or generating C# code, apply proven ideas from Rust, F#, Go, Kotlin/Swift, Erlang/Elixir, and Goose. Prefer these over typical C# habits such as exceptions for control flow, pervasive nullability, mutable shared state, deep inheritance, and pointer-chasing object graphs.



\## Core Principles



\### 1. Explicit Success and Failure (Result / Option)

\- Prefer returning a Result-like or Option-like type over throwing exceptions for expected failure cases.

\- Prefer Option-like types over returning null.

\- Recommended libraries when available — LanguageExt, OneOf, ErrorOr, FluentResults, or a lightweight custom Result/Option.

\- If no library is present, introduce a simple sealed hierarchy or record-based Result/Option and use pattern matching.

\- Make the possibility of absence or failure visible in the type signature.

\- Inspired by Rust `Result`/`Option`, F# `Result`/`Option`, Go multiple returns, and Zig error unions.



\### 2. Exhaustive Handling \& Discriminated Unions

\- Favor switch expressions and pattern matching that cover all cases.

\- Model domains with discriminated-union style types (abstract record + sealed derived records).

\- Avoid fall-through or default-only handling when the set of cases is known.

\- When using Result/Option or union types, force callers to handle every meaningful case.

\- Strongly influenced by F#, Rust enums, and Kotlin sealed classes.



\### 3. Immutability by Default

\- Prefer `readonly` fields, `init` properties, and `record` types.

\- Prefer immutable collections (`ImmutableArray`, `ImmutableList`, etc.) or `IReadOnlyList`/`IReadOnlyDictionary` at API boundaries.

\- Mutate only when necessary and keep mutation local and obvious.

\- Drawn from Rust, F#, Clojure, and Kotlin data classes.



\### 4. Ownership and Lifetime Thinking

\- Even though C# has a GC, think about who owns data and when it is no longer needed.

\- Prefer clear ownership transfer over freely shared mutable references.

\- Use `using` / `IAsyncDisposable` diligently for resources that need deterministic cleanup.

\- Prefer `Span<T>`, `ReadOnlySpan<T>`, `Memory<T>` for performance-critical short-lived data.

\- Core idea from Rust, reinforced by modern C++ and Zig.



\### 5. Composition over Inheritance

\- Prefer small focused types composed together over deep class hierarchies.

\- Use interfaces (especially with default interface methods) for behavior.

\- Favor sealed classes/records unless inheritance is clearly required.

\- Common to Rust, Go, and modern Kotlin/Swift style.



\### 6. Fearless \& Structured Concurrency

\- Minimize shared mutable state.

\- Prefer message-passing, `Channel<T>`, or actor-style designs over locks when practical.

\- When state must be shared, make ownership of the lock or synchronization primitive explicit.

\- Consider actor / supervision ideas (Orleans, Akka.NET, or custom) for long-running systems.

\- Inspired by Rust’s type-system guarantees, Go channels, and Erlang/Elixir supervision trees.



\### 7. Safe \& Efficient Async/Await

\- Async all the way — avoid blocking on asynchronous code.

\- Prefer `async Task` / `async Task<T>` / `async ValueTask` / `async ValueTask<T>` over `async void` (except event handlers).

\- Accept and propagate `CancellationToken`.

\- Observe exceptions (await tasks or explicitly handle them).

\- Use `.ConfigureAwait(false)` in library and infrastructure code.

\- Prefer `ValueTask` when a method often completes synchronously.

\- Avoid unnecessary `Task.Run` for I/O-bound work.

\- Clean up resources with `await using` / `IAsyncDisposable`.

\- Treat cancellation as part of ownership and lifetime.



\### 8. Flat, Allocation-Conscious Data Layout (Goose-inspired)

\- Prefer contiguous, cache-friendly layouts over deep pointer-chasing object graphs.

\- Favor structs, arrays, and inline nested data when performance or locality matters.

\- Prefer indices or stable handles over long-lived object references into growable collections.

\- Minimize allocations; reach for `ArrayPool`, stack allocation, recycling, or arena-style patterns in hot paths.

\- Design data so related values live together and serialization/memory-mapping stays simple when relevant.

\- Keep share-nothing discipline for concurrency (reinforces principle 6).



\### 9. Explicit over Implicit

\- Make important decisions visible in types and signatures rather than hidden in documentation.

\- Avoid "stringly-typed" or magic-value APIs.

\- Prefer domain-specific types over primitive obsession.

\- Shared value across Rust, F#, and Go.



\### 10. Simplicity Bias (from Go)

\- Prefer clear, boring, readable code over clever abstractions when both solve the problem.

\- Resist speculative generality.

\- Small interfaces and obvious control flow are features.



\## Practical Application Rules



When reviewing or rewriting C# code:



1\. Replace methods that return null or throw for expected cases with Result/Option-style returns.

2\. Convert mutable data holders into records or readonly structs where appropriate.

3\. Introduce discriminated-union style types + pattern matching for multi-case domains.

4\. Reduce public mutable state; expose read-only views.

5\. Prefer dependency injection of abstractions and composition.

6\. For concurrency, reach for channels or actors before shared mutable collections + locks.

7\. For async code, apply the Safe \& Efficient Async/Await rules strictly.

8\. For performance-sensitive or data-heavy code, prefer flat layouts, indices/handles, and allocation control (Goose-inspired).

9\. Keep public APIs honest about failure modes and absence of values.



\## What Not to Do

\- Do not remove all exceptions — reserve them for truly exceptional / unrecoverable situations.

\- Do not introduce heavy functional libraries unless the project already uses them or the user requests it.

\- Do not sacrifice C# idioms so severely that the code becomes unreadable to normal C# developers. Aim for modern, safe, expressive C#.

\- Do not claim memory safety or data-race freedom guarantees that the C# type system and runtime cannot provide.

\- Do not force actor-model complexity on simple request/response code.

\- Do not block on async code with `.Result`, `.Wait()`, or `.GetAwaiter().GetResult()` in application logic.

\- Do not use `async void` outside of event handlers.

\- Do not chase zero-allocation or extreme flatness when it harms clarity for non-critical code.



\## Output Style

\- When making changes, briefly note which principle (and source language when useful) drove each significant decision.

\- Prefer incremental, reviewable improvements over massive rewrites unless asked for a full redesign.



For concrete code patterns see `patterns.md`.

