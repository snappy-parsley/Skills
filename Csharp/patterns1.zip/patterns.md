# Detailed Patterns — Cross-Language Rules Applied to C#

## Result and Option Patterns

### Minimal custom Result (no external library)

public readonly record struct Result<T>
{
    public T? Value { get; init; }
    public string? Error { get; init; }
    public bool IsSuccess => Error is null;

    public static Result<T> Ok(T value) => new() { Value = value };
    public static Result<T> Fail(string error) => new() { Error = error };
}

// Usage
Result<User> GetUser(int id)
{
    if (id <= 0) return Result<User>.Fail("Invalid id");
    var user = db.Find(id);
    return user is null 
        ? Result<User>.Fail("Not found") 
        : Result<User>.Ok(user);
}

// Call site
var result = GetUser(42);
string message = result switch
{
    { IsSuccess: true, Value: var user } => $"Hello {user.Name}",
    { Error: var err } => $"Error: {err}"
};
### Using LanguageExt, OneOf, ErrorOr, etc.
Prefer the project’s existing functional library if one is already referenced. Mentally map Rust’s ? operator and F#’s railway-oriented style to early returns or monadic bind (Bind / SelectMany).

## Discriminated Unions (F# / Rust / Kotlin influence)

public abstract record PaymentResult;
public sealed record PaymentSucceeded(TransactionId Id, Money Amount) : PaymentResult;
public sealed record PaymentFailed(string Reason, ErrorCode Code) : PaymentResult;
public sealed record PaymentPending(PaymentId Id) : PaymentResult;

// Exhaustive handling
string Describe(PaymentResult r) => r switch
{
    PaymentSucceeded s => $"Paid {s.Amount}",
    PaymentFailed f => $"Failed: {f.Reason}",
    PaymentPending p => $"Pending {p.Id}",
    // Add new cases here; tools and reviewers should catch missing ones
};
Use this style for domain events, command results, protocol messages, and any closed set of variants.

## Ownership-Minded Resource Handling

public sealed class Connection : IAsyncDisposable
{
    public static async Task<Connection> ConnectAsync(...) { ... }
    public async ValueTask DisposeAsync() { ... }
}

// Caller
await using var conn = await Connection.ConnectAsync(...);
Treat `IDisposable / IAsyncDisposable as the closest equivalent to Rust’s Drop. Keep creation and cleanup pairs obvious.

## Immutability Patterns

``csharp
// Prefer
public sealed record Order(OrderId Id, ImmutableList<OrderLine> Lines, Money Total);

// Over
public class Order
{
    public List<OrderLine> Lines { get; set; } = new();
}

At API boundaries return `IReadOnlyList<T>`, `IReadOnlyDictionary<TKey,TValue>`, or immutable collections.

## Concurrency Patterns

### Message-passing (Go + Rust influence)
csharp
var channel = Channel.CreateBounded<WorkItem>(100);

// Producer
await channel.Writer.WriteAsync(item);

// Consumer
await foreach (var item in channel.Reader.ReadAllAsync())
{
    await ProcessAsync(item);
}
`

### Actor-style sketch (Erlang/Orleans influence)
- Encapsulate mutable state inside a single-threaded actor or grain.
- Communicate only via messages or method calls that are turned into messages.
- Use supervision (restart policies) for long-running work instead of trying to handle every failure locally.

### Lock ownership discipline
When a lock is unavoidable, keep the protected data private and expose only thread-safe operations. Document the ownership relationship clearly.

## When to Reach for Spans

Use `Span<T>` / `ReadOnlySpan<T>` / `Memory<T>` when:
- You want to express non-owning access to existing memory.
- You want to reduce allocations in hot paths.
- The lifetime of the data is clearly tied to a stack frame or a known owner.

This is the closest practical equivalent to Rust borrowing for performance-critical code.

## Simplicity Checks (Go influence)

Before adding an abstraction, ask:
- Can this be a simple function or record?
- Is the interface small and obvious?
- Will a future reader understand the control flow in one pass?

Prefer the boring solution when it is clear and correct.